package org.example.mydiary;

import static org.example.mydiary.Calendar_Fragment.boldDecorator;
import static org.example.mydiary.Calendar_Fragment.maxDecorate;
import static org.example.mydiary.Calendar_Fragment.oneDayDecorator;
import static org.example.mydiary.Calendar_Fragment.saturdayDecorator;
import static org.example.mydiary.Calendar_Fragment.sundayDecorator;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;


public class MainActivity extends AppCompatActivity implements Calendar_Fragment.OnTimePickerSetListener {

    String date, fileName_content, fileName_title, fileName_image, fileName_weather;
    View v;
    ImageView imageView;
    TextView textcontent, title, weather;

    AlarmManager alarmManager;
    Context context;
    PendingIntent pendingIntent;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.context=this;

        //알람을 위해 현재 시간 날짜 확인
        Date date=new Date();
        DateFormat sdf=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.KOREAN);
        TimeZone tz=TimeZone.getTimeZone("Asia/Seoul");
        sdf.setTimeZone(tz);
        String[] getTime=sdf.format(date).split(" ");
        String[] d=getTime[0].toString().split("-");

        //달력 실행
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fm.beginTransaction();
                fragmentTransaction.add(R.id.frame1, new Calendar_Fragment()).commit();

                //하단 버튼 실행
                BottomNavigationView bottom_menu = findViewById(R.id.talk_bottom);
                bottom_menu.setOnNavigationItemSelectedListener(new BottomMenuClick());

                //알람
                alarmManager=(AlarmManager) getSystemService(ALARM_SERVICE);
                Calendar calendar=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));

                //알람 날짜
                calendar.set(Calendar.YEAR, Integer.parseInt(d[0]));
                calendar.set(Calendar.MONTH, Integer.parseInt(d[1])-1);
                calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(d[2]));
                calendar.set(Calendar.HOUR_OF_DAY, 20);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                //calendar.set(Calendar.MILLISECOND, 0);

                Log.i("Hour", String.valueOf(calendar.get(Calendar.HOUR_OF_DAY)));
                Intent alarm_intent=new Intent(getApplicationContext(), AlarmReciver.class);
                pendingIntent=PendingIntent.getBroadcast(MainActivity.this, 0, alarm_intent, PendingIntent.FLAG_UPDATE_CURRENT);
                //2일 마다 반복  24*60*60*2,  calendar.getTimeInMillis()
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),24*60*60*7, pendingIntent);

                //알람내용 작성
                CharSequence name="MY Diary";
                String description="알림";
                int important= NotificationManager.IMPORTANCE_DEFAULT;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    NotificationChannel notificationChannel=new NotificationChannel("channel_id", name, important);
                    notificationChannel.setDescription(description);
                    NotificationManager notificationManager=getSystemService(NotificationManager.class);
                    notificationManager.createNotificationChannel(notificationChannel);
                }

            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    //달력에서 받아오기
    @Override
    public void OnTimePickerSet(String d, View view) {
        date = d;
        v = view;
    }

    //bottom 메뉴 선택시 커스텀 뷰
    class BottomMenuClick implements BottomNavigationView.OnNavigationItemSelectedListener {

        @RequiresApi(api = Build.VERSION_CODES.Q)
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.first_tab: {
                    //calendar_Fragment
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            List<Fragment> fragment = getSupportFragmentManager().getFragments();
                            /*if(fragment!=null){
                                fragment.rem
                            }*/
                            getSupportFragmentManager().beginTransaction().replace(R.id.frame1, new Calendar_Fragment()).commit();
                        }
                    }).start();
                    break;
                }

                case R.id.second_tab: {
                    //Scroll_diary
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            getSupportFragmentManager().beginTransaction().replace(R.id.frame1, new Scroll_date_fragment()).commit();
                        }
                    }).start();
                    break;
                }
                case R.id.third_tab: {//삭제
                    Fragment fragment = getSupportFragmentManager().getFragments().get(0);
                    Fragment fragment1=getSupportFragmentManager().getFragments().get(1);
                    if (fragment instanceof Calendar_Fragment ||(fragment instanceof Scroll_diary && fragment1 instanceof Calendar_Fragment)) {
                        //Alert창 삽입
                        AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(MainActivity.this);
                        myAlertBuilder.setTitle("삭제");
                        myAlertBuilder.setMessage("정말로 삭제하시겠습니다. 삭제 버튼을 누르면 복구할 수 없습니다.");
                        //버튼 추가
                        myAlertBuilder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if (date != null) {
                                    fileName_content = date + "content";
                                    fileName_image = date + "image";
                                    fileName_title = date + "title";
                                    fileName_weather = date + "weather";
                                    //삭제
                                    boolean bDel = deleteFile(fileName_content);
                                    boolean bDel2 = deleteFile(fileName_weather);
                                    boolean bDel3 = deleteFile(fileName_title);

                                    File file = getCacheDir();
                                    File[] flist = file.listFiles();
                                    for (int j = 0; j < flist.length; j++) {
                                        if (flist[j].getName().equals(fileName_image)) {
                                            flist[j].delete();
                                        }
                                    }

                                    if (bDel & bDel2 & bDel3) {
                                        textcontent = (TextView) v.findViewById(R.id.contents);
                                        title = (TextView) v.findViewById(R.id.diary_title);
                                        weather = (TextView) v.findViewById(R.id.weather);
                                        imageView = (ImageView) v.findViewById(R.id.diary_image);

                                        title.setText("");
                                        weather.setText("");
                                        textcontent.setText("");
                                        imageView.setImageBitmap(null);

                                        MaterialCalendarView materialCalendarView = (MaterialCalendarView) v.findViewById(R.id.materialCalendarView);

                                        materialCalendarView.removeDecorators();
                                        materialCalendarView.addDecorators(saturdayDecorator, sundayDecorator, oneDayDecorator, maxDecorate, boldDecorator);
                                        Calendar_Fragment.FindDiary f = new Calendar_Fragment.FindDiary();
                                        materialCalendarView.addDecorators(f);
                                        Toast.makeText(getApplicationContext(), "삭제되었습니다", Toast.LENGTH_LONG).show();

                                    } else {
                                        Toast.makeText(getApplicationContext(), "삭제 오류가 발생하였습니다. 일기가 존재하는지 확인해 주세요.", Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "check date", Toast.LENGTH_LONG).show();
                                }
                            }
                        }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //취소
                                Toast.makeText(getApplicationContext(), "취소되었습니다", Toast.LENGTH_LONG).show();
                            }
                        });

                        AlertDialog dialog = myAlertBuilder.create();
                        dialog.show();
                        break;
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"삭제는 달력 페이지에서만 가능합니다.", Toast.LENGTH_SHORT).show();
                    }
                }
                default:
                    break;

                }
            return true;
        }
    }
}

