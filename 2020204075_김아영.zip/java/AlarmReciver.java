package org.example.mydiary;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReciver extends BroadcastReceiver {
    Context context;
    @Override
    public void onReceive(Context context, Intent intent) {
        this.context=context;

        Intent service_intent=new Intent(context, Alarm.class);
        context.startService(service_intent);
    }
}
