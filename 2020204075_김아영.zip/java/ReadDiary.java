package org.example.mydiary;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;

public class ReadDiary extends AppCompatActivity {
    String date, fileName_content, fileName_image, fileName_title, fileName_weather;
    TextView title, weather, textcontent, put_date;
    ImageView imageView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_readdiary);

        Intent intent=getIntent();
        date=intent.getExtras().getString("date");

        put_date=(TextView)findViewById(R.id.date3);
        title=(TextView) findViewById(R.id.title2);
        weather=(TextView) findViewById(R.id.weather2);
        textcontent=(TextView) findViewById(R.id.content4);
        imageView=(ImageView) findViewById(R.id.imageVIew3);

        find_data();
    }

    public void find_data(){

        put_date.setText(date);

        FileInputStream inputStream, weatherStream, titleStream;

        fileName_content = date + "content";
        fileName_image = date + "image";
        fileName_title = date + "title";
        fileName_weather = date + "weather";

        try {
            //이미지 가져오기
            String imagePath = getCacheDir() + "/" + fileName_image;
            Bitmap bm = BitmapFactory.decodeFile(imagePath);
            imageView.setImageBitmap(bm);
            imageView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
        }

        try {
            //내용가져오기
            inputStream = openFileInput(fileName_content);
            byte[] data = new byte[inputStream.available()];
            while (inputStream.read(data) != -1) {
            }
            textcontent.setText(new String(data));
            textcontent.setVisibility(View.VISIBLE);

            if (inputStream != null) {
                inputStream.close();
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "내용이 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

        try {
            //제목
            titleStream = openFileInput(fileName_title);
            byte[] data = new byte[titleStream.available()];
            while (titleStream.read(data) != -1) {
            }
            title.setText(new String(data));
            title.setVisibility(View.VISIBLE);

            if (titleStream != null) {
                titleStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            //날씨
            weatherStream = openFileInput(fileName_weather);
            byte[] data = new byte[weatherStream.available()];
            while (weatherStream.read(data) != -1) {
            }
            ;
            weather.setText(new String(data));
            weather.setVisibility(View.VISIBLE);

            if (weatherStream != null) {
                weatherStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onBackPressed(){
        finish();
    }
}
