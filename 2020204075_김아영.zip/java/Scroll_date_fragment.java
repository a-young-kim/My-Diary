package org.example.mydiary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.prolificinteractive.materialcalendarview.CalendarDay;

public class Scroll_date_fragment extends Fragment {
    View v;
    String today_year, today_month, today_day;
    TextView find_date;
    Button button;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        //View
        v = inflater.inflate(R.layout.date_scroll, container, false);

        find_date=(TextView)v.findViewById(R.id.find_date);

        button=(Button) v.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a=find_date.getText().toString();
                if(!a.contains("-")){
                    Toast.makeText(getContext(), "형식에 맞춰 입력해주세요", Toast.LENGTH_SHORT).show();
                }

                else {
                    String year, month;
                    year = a.split("-", 2)[0];
                    ;
                    month = a.split("-", 2)[1];

                    if (month.contains("-")) {
                        Toast.makeText(getContext(), "형식에 맞춰 입력해주세요", Toast.LENGTH_SHORT).show();
                    }

                    else if(Integer.parseInt(year)<=2010){
                        Toast.makeText(getContext(), "입력할 수 없는 년도입니다.", Toast.LENGTH_SHORT).show();
                    }

                    else if (Integer.parseInt(year) < Integer.parseInt(today_year) && Integer.parseInt(month) <= 12
                    || Integer.parseInt(year) == Integer.parseInt(today_year)&&Integer.parseInt(month)<=Integer.parseInt(today_month)) {

                        Bundle bundle = new Bundle();
                        bundle.putString("year", year);
                        bundle.putString("month", month);

                        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
                        Scroll_diary scroll_diary = new Scroll_diary();

                        scroll_diary.setArguments(bundle);

                        transaction.replace(R.id.frame2, scroll_diary);
                        transaction.commit();
                    }

                    else {
                        Toast.makeText(getContext(), "불러올 수 없는 월입니다.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        //오늘 날짜 default
        String[] a = new Calendar_Fragment().setday(CalendarDay.today()).split("-", 3);
        today_year = a[0];
        today_month = a[1];
        today_day = a[2];

        find_date.setHint(today_year+"-"+today_month);
        Bundle bundle=new Bundle();
        bundle.putString("year", today_year);
        bundle.putString("month", today_month);

        FragmentTransaction transaction=getFragmentManager().beginTransaction();
        Scroll_diary scroll_diary=new Scroll_diary();

        scroll_diary.setArguments(bundle);

        transaction.replace(R.id.frame2, scroll_diary);
        transaction.commit();

        return v;
    }
}
