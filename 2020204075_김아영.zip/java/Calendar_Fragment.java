package org.example.mydiary;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.OnMonthChangedListener;
import com.prolificinteractive.materialcalendarview.OnRangeSelectedListener;
import com.prolificinteractive.materialcalendarview.spans.DotSpan;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class Calendar_Fragment extends Fragment {

    MaterialCalendarView materialCalendarView;
    SwipeRefreshLayout swipeRefreshLayout;
    static String date;
    String fileName_content, fileName_title, fileName_image, fileName_weather;
    ImageView imageView;
    TextView textcontent, title, weather;
    static View v;
    FindDiary f;
    static SundayDecorator sundayDecorator = new SundayDecorator();
    static SaturdayDecorator saturdayDecorator = new SaturdayDecorator();
    static final OneDayDecorator oneDayDecorator = new OneDayDecorator();
    static MaxDecorate maxDecorate = new MaxDecorate();
    static BoldDecorator boldDecorator = new BoldDecorator();


    private OnTimePickerSetListener onTimePickerSetListener;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        //View
        v = inflater.inflate(R.layout.calendar, container, false);

        //캘린더뷰 수정, 핸드폰 날짜 기준준
        materialCalendarView = (MaterialCalendarView) v.findViewById(R.id.materialCalendarView);
        materialCalendarView.setCurrentDate(new Date(System.currentTimeMillis()));
        materialCalendarView.setDateSelected(new Date(System.currentTimeMillis()), true);


       materialCalendarView.addDecorators(saturdayDecorator, sundayDecorator, oneDayDecorator, maxDecorate, boldDecorator);
        f = new FindDiary(CalendarDay.today().getYear(), CalendarDay.today().getMonth() + 1);
        materialCalendarView.addDecorators(f);


        //오늘 날짜
        date = setday(CalendarDay.today());

        textcontent = (TextView) v.findViewById(R.id.contents);
        title = (TextView) v.findViewById(R.id.diary_title);
        weather = (TextView) v.findViewById(R.id.weather);
        imageView = (ImageView) v.findViewById(R.id.diary_image);

        //새로고침
        swipeRefreshLayout = (SwipeRefreshLayout) v.findViewById(R.id.swipe);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                find_data(date);

                materialCalendarView.removeDecorators();
                materialCalendarView.addDecorators(saturdayDecorator, sundayDecorator, oneDayDecorator, maxDecorate, boldDecorator);
                f = new FindDiary(CalendarDay.today().getYear(), CalendarDay.today().getMonth() + 1);
                materialCalendarView.addDecorators(f);

                onTimePickerSetListener.OnTimePickerSet(date, v);
                swipeRefreshLayout.setRefreshing(false);

            }
        });

        //캘린더에서 날짜 선택시
        materialCalendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay select_date, boolean selected) {
                date = setday(select_date);
                find_data(date);
                onTimePickerSetListener.OnTimePickerSet(date, v);
                Handler handler=new Handler() {
                    public void handleMessage(Message msg) {
                        super.handleMessage(msg);

                        materialCalendarView.removeDecorators();
                        materialCalendarView.addDecorators(saturdayDecorator, sundayDecorator, oneDayDecorator, maxDecorate, boldDecorator);
                        f = new FindDiary(select_date.getYear(), select_date.getMonth() + 1);
                        materialCalendarView.addDecorators(f);
                    }
                };
            }
        });

        //달을 바꿀 경우
        materialCalendarView.setOnMonthChangedListener(new OnMonthChangedListener() {
            @Override
            public void onMonthChanged(MaterialCalendarView widget, CalendarDay date) {
                Thread t=new Thread(new Runnable() {
                    @Override
                    public void run() {
                        materialCalendarView.removeDecorators();
                        materialCalendarView.addDecorators(saturdayDecorator, sundayDecorator, oneDayDecorator, maxDecorate, boldDecorator);
                        f = new FindDiary(date.getYear(), date.getMonth() + 1);
                        materialCalendarView.addDecorators(f);

                        title.setText(" ");
                        weather.setText(" ");
                        textcontent.setText(" ");
                        imageView.setImageBitmap(null);
                    }
                });
                t.start();
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        setHasOptionsMenu(true);
        onTimePickerSetListener.OnTimePickerSet(date, v);
        return v;
    }

    public String setday(CalendarDay cur_date) {
        int year, month, day;
        String result;

        year = cur_date.getYear();
        month = (cur_date.getMonth() + 1);
        day = cur_date.getDay();

        result = Integer.toString(year) + '-' + Integer.toString(month) + '-' + Integer.toString(day);
        return result;
    }

    public interface OnTimePickerSetListener {
        void OnTimePickerSet(String date, View v);
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnTimePickerSetListener) {
            onTimePickerSetListener = (OnTimePickerSetListener) context;
        }
    }

    public void onDetach() {
        super.onDetach();
        onTimePickerSetListener = null;
    }

    //일기 찾기
    public void find_data(String date) {

        title.setText(" ");
        weather.setText(" ");
        textcontent.setText(" ");
        imageView.setImageBitmap(null);

        FileInputStream inputStream, weatherStream, titleStream;

        fileName_content = date + "content";
        fileName_image = date + "image";
        fileName_title = date + "title";
        fileName_weather = date + "weather";

        try {
            //이미지 가져오기
            String imagePath = v.getContext().getCacheDir() + "/" + fileName_image;
            Bitmap bm = BitmapFactory.decodeFile(imagePath);
            imageView.setImageBitmap(bm);
            imageView.setVisibility(View.VISIBLE);
        } catch (Exception e) {
        }

        try {
            //내용가져오기
            inputStream = v.getContext().openFileInput(fileName_content);
            byte[] data = new byte[inputStream.available()];
            while (inputStream.read(data) != -1) {
            }
            textcontent.setText(new String(data));
            textcontent.setVisibility(View.VISIBLE);

            if (inputStream != null) {
                inputStream.close();
            }
        } catch (Exception e) {
            Toast.makeText(v.getContext(), "내용이 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

        try {
            //제목
            titleStream = v.getContext().openFileInput(fileName_title);
            byte[] data = new byte[titleStream.available()];
            while (titleStream.read(data) != -1) {
            }
            title.setText(new String(data));
            title.setVisibility(View.VISIBLE);

            if (titleStream != null) {
                titleStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            //날씨
            weatherStream = v.getContext().openFileInput(fileName_weather);
            byte[] data = new byte[weatherStream.available()];
            while (weatherStream.read(data) != -1) {
            }
            ;
            weather.setText(new String(data));
            weather.setVisibility(View.VISIBLE);

            if (weatherStream != null) {
                weatherStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   //토요일을 파란색으로
   static class SaturdayDecorator implements DayViewDecorator {
      private final java.util.Calendar calendar = java.util.Calendar.getInstance();

      public SaturdayDecorator() {
      }

      @Override
      public boolean shouldDecorate(CalendarDay day) {
         day.copyTo(calendar);
         int weekDay = calendar.get(java.util.Calendar.DAY_OF_WEEK);
         return weekDay == java.util.Calendar.SATURDAY;
      }

      @Override
      public void decorate(DayViewFacade view) {
         view.addSpan(new ForegroundColorSpan(Color.BLUE));
      }
   }

   //일요일을 빨간색으로
   static class SundayDecorator implements DayViewDecorator {
      private final java.util.Calendar calendar = java.util.Calendar.getInstance();

      @Override
      public boolean shouldDecorate(CalendarDay day) {
         day.copyTo(calendar);
         int weekDay = calendar.get(java.util.Calendar.DAY_OF_WEEK);
         return weekDay == java.util.Calendar.SUNDAY;
      }

      @Override
      public void decorate(DayViewFacade view) {
         view.addSpan(new ForegroundColorSpan(Color.RED));
      }
   }

   //오늘 날짜 표시하기
   static class OneDayDecorator implements DayViewDecorator {
      private CalendarDay d;

      public OneDayDecorator() {

         d = CalendarDay.today();
      }

      @Override
      public boolean shouldDecorate(CalendarDay day) {
         return day.equals(d);
      }

      @Override
      public void decorate(DayViewFacade view) {
         view.addSpan(new RelativeSizeSpan(1.2f));
      }

      public void setDate(Date date) {
         this.d = CalendarDay.from(date);
      }
   }
   //색 연하게
   static class MaxDecorate implements DayViewDecorator{
      int year=CalendarDay.today().getYear();
      int month=CalendarDay.today().getMonth();
      int today=CalendarDay.today().getDay();

      @Override
      public boolean shouldDecorate(CalendarDay day) {
         if(day.getYear()>year){
            return true;
         }
         else if(day.getYear()==year&& day.getMonth()>month){
            return true;
         }
         else if(day.getYear()==year&&day.getMonth()==month&&today<day.getDay()){
            return true;
         }
         return false;
      }

      @Override
      public void decorate(DayViewFacade view) {
         view.addSpan(new ForegroundColorSpan(Color.parseColor("#d2d2d2")){});
         view.setDaysDisabled(true);
      }
   }

   static class BoldDecorator implements DayViewDecorator{

      @Override
      public boolean shouldDecorate(CalendarDay day) {
         return true;
      }

      @Override
      public void decorate(DayViewFacade view) {
         view.addSpan(new StyleSpan(Typeface.BOLD){});
      }
   }

   public void onCreateOptionsMenu(Menu menu, MenuInflater inflater){
      super.onCreateOptionsMenu(menu, inflater);
      inflater.inflate(R.menu.make_diary, menu);
   }

   public boolean onOptionsItemSelected(MenuItem item){
      switch (item.getItemId()){
         case R.id.make_diary:{
            //WritePage로 이동
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Intent write_intent=new Intent(v.getContext(), WritePage.class);
                    write_intent.putExtra("Date", date);
                    startActivityForResult(write_intent, 0);
                }
           }).start();
             break;
         }
         default:break;
      }
      return super.onOptionsItemSelected(item);
   }

   @Override
   public void onResume() {
      super.onResume();
      find_data(date);
       materialCalendarView.addDecorators(saturdayDecorator,sundayDecorator, oneDayDecorator, maxDecorate, boldDecorator);
       f=new FindDiary(date.split("-", 3)[0], date.split("-", 3)[1]);
       materialCalendarView.addDecorators(f);
   }

   static class FindDiary implements DayViewDecorator{
      List<String> filesName=new ArrayList<>();
      int year, month;

      public FindDiary(){
         String[] a=date.split("-", 3);
         year=Integer.valueOf(a[0]);
         month=Integer.valueOf(a[1]);
         this.Find();
      }
      private FindDiary(int y, int m){
         this.year=y;
         this.month=m;
         this.Find();
      }

      private FindDiary(String y, String m){
          this.year=Integer.valueOf(y);
          this.month=Integer.valueOf(m);
      }

      public void Find() {
          Thread thread=new Thread(new Runnable() {
              @Override
              public void run() {
                  for (int i = 1; i < 32; i++) {
                      String d = String.valueOf(year) + "-" + String.valueOf(month) + "-" + Integer.toString(i);
                      String file_title = d + "title";
                      try {
                          InputStream inputStream = v.getContext().openFileInput(file_title);
                          filesName.add(d);
                          inputStream.close();
                      } catch (Exception e) {
                          continue;
                      }
                  }
              }
          });
          thread.start();
          try {
              thread.join();
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }

      @Override
      public boolean shouldDecorate(CalendarDay day) {
         int year=day.getYear();
         int month=day.getMonth()+1;
         int _day=day.getDay();
         String result=Integer.valueOf(year)+"-"+Integer.valueOf(month)+"-"+Integer.valueOf(_day);
        if(filesName.contains(result)){
           return true;
         }
         return false;
      }

      @Override
      public void decorate(DayViewFacade view) {
         view.addSpan(new DotSpan(5, Color.RED){});
      }
   }
}
