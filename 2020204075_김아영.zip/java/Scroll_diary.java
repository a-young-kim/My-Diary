package org.example.mydiary;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.prolificinteractive.materialcalendarview.CalendarDay;

import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Scroll_diary extends Fragment{

    View v;
    String year, month, day;
    String date, file_date, file_title;
    TextView find_date;
    Button button;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        //View
        v = inflater.inflate(R.layout.scroll_diary, container, false);

        if(v==null){
            return null;
        }
        if(getArguments()!=null){
            month=getArguments().getString("month");
            year=getArguments().getString("year");
        }

        LinkedHashMap<String,String>filesNameList=new LinkedHashMap<>();
        filesNameList=FileList();

        ListView listView=(ListView) v.findViewById(R.id.listView);

        MyAdapter adapter=new MyAdapter(inflater, getContext());
        for(String key:filesNameList.keySet()){
            adapter.addItem(new Myitem(key, filesNameList.get(key)));
        }
        listView.setAdapter(adapter);

        return v;
    }

    private LinkedHashMap<String, String> FileList(){
        LinkedHashMap<String,String> filesNameList=new LinkedHashMap<>();
        for(int i=1;i<32;i++){
            date=year+"-"+month+"-"+Integer.toString(i);
            file_title = date + "title";

            try {
                InputStream inputStream= getActivity().openFileInput(file_title);
                byte[] data = new byte[inputStream.available()];
                while (inputStream.read(data) != -1) {
                }
                filesNameList.put(date, new String(data));
                inputStream.close();
            } catch (Exception e) {

            }
        }
        return filesNameList;
    }

}
