package org.example.mydiary;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutionException;

public class WritePage extends AppCompatActivity {

    private long backPressTime=0;
    private String fileName_content, fileName_weather, fileName_title, fileName_image;
    Button button;
    TextView date;
    EditText weather,title, textcontent;
    ImageView imageView;
    Bitmap forImage;
    String m;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_page);

        //activity 간에 데이터 전달
        //날짜
        date=(TextView) findViewById(R.id.date2);
        Intent intent=getIntent();
        m=intent.getStringExtra("Date");
        date.setText(m);

        //파일 설정
        fileName_image = m + "image";
        fileName_content = m + "content";
        fileName_title = m + "title";
        fileName_weather = m + "weather";

        textcontent = (EditText)findViewById(R.id.content2);
        weather = (EditText)findViewById(R.id.make_weather2);
        title = (EditText)findViewById(R.id.make_title);
        imageView=(ImageView) findViewById(R.id.imageVIew2);
        button=(Button)findViewById(R.id.weather_button);

        find_data(m);

        new Thread(new Runnable() {
            @Override
            public void run() {
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Weather w=new Weather();
                        w.execute(m);
                        try {
                            weather.setText(w.get());
                        } catch (Exception e) {
                            weather.setText("날씨를 불러올 수 없습니다.");
                        }
                    }
                });
            }
        }).start();

    }
    //파일 저장 버튼
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.write_menu, menu);
        return true;
    }

    //저장
    public boolean onOptionsItemSelected(MenuItem item) {

        FileOutputStream outputStream = null;
        FileOutputStream weatherStream = null;
        FileOutputStream titleStream = null;

        String s1 = textcontent.getText().toString();
        String s2 = weather.getText().toString();
        String s4 = title.getText().toString();

        if (s1.length() == 0 || s2.length() == 0 || s4.length() == 0) {
            Toast.makeText(getApplicationContext(), "빈칸은 허용하지 않습니다!", Toast.LENGTH_LONG).show();

        } else {
            saveBitmapToJpeg(forImage);

            try {
                outputStream = openFileOutput(fileName_content, MODE_PRIVATE);
                weatherStream = openFileOutput(fileName_weather, MODE_PRIVATE);
                titleStream = openFileOutput(fileName_title, MODE_PRIVATE);

                //에디트 박스에 저장된 스트링 데이터를 스트림에 기록함
                outputStream.write(textcontent.getText().toString().getBytes());
                outputStream.close();
                weatherStream.write(weather.getText().toString().getBytes());
                weatherStream.close();
                titleStream.write(title.getText().toString().getBytes());
                titleStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            finish();//activity 끝

        }
        return super.onOptionsItemSelected(item);
    }

    //사진 선택시
    public void selectImage(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 101);
    }

    //사진 불러오기
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101) {//사진 선택 코드 번호
            if (resultCode == RESULT_OK) {
                Uri fileUri = data.getData();
                ContentResolver resolver = getContentResolver();
                InputStream inputStream = null;
                try {
                    inputStream = resolver.openInputStream(fileUri);
                    Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);
                    imageView.setImageBitmap(imgBitmap);
                    inputStream.close();
                    forImage = imgBitmap;
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "실패", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    //사진 저장하기
    public void saveBitmapToJpeg(Bitmap bitmap) {
        File tempFile = new File(getCacheDir(), fileName_image);
        try {
            tempFile.createNewFile();
            FileOutputStream out = new FileOutputStream(tempFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
        } catch (Exception e) {
        }
    }

    //뒤로 두번 연속으로 누르면 종료 처리
    public void onBackPressed(){
        if(System.currentTimeMillis()-backPressTime>=2000){
            backPressTime=System.currentTimeMillis();
            Toast.makeText(getApplicationContext(), "백(Back) 버튼을 한 번 더 누르면 종료합니다.", Toast.LENGTH_LONG).show();
        }
        else if(System.currentTimeMillis()-backPressTime<2000){
            finish();
        }
    }
    public void find_data(String date) {
        FileInputStream inputStream, weatherStream, titleStream;

        fileName_content = date + "content";
        fileName_image = date + "image";
        fileName_title = date + "title";
        fileName_weather = date + "weather";

        try {
            //이미지 가져오기
            String imagePath = getCacheDir() + "/" + fileName_image;
            Bitmap bm = BitmapFactory.decodeFile(imagePath);

            if(bm!=null){
                imageView.setImageBitmap(bm);
                imageView.setVisibility(View.VISIBLE);
            }

        } catch (Exception e) {

        }

        try {
            //내용가져오기
            inputStream = openFileInput(fileName_content);
            byte[] data = new byte[inputStream.available()];
            while (inputStream.read(data) != -1) {
            }
            textcontent.setText(new String(data));
            textcontent.setVisibility(View.VISIBLE);

            if (inputStream != null) {
                inputStream.close();
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "내용이 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

        try {
            //제목
            titleStream = openFileInput(fileName_title);
            byte[] data = new byte[titleStream.available()];
            while (titleStream.read(data) != -1) {
            }
            title.setText(new String(data));
            title.setVisibility(View.VISIBLE);

            if (titleStream != null) {
                titleStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            //날씨
            weatherStream = openFileInput(fileName_weather);
            byte[] data = new byte[weatherStream.available()];
            while (weatherStream.read(data) != -1) {
            }
            ;
            weather.setText(new String(data));
            weather.setVisibility(View.VISIBLE);

            if (weatherStream != null) {
                weatherStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
