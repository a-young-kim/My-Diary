package org.example.mydiary;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;

import androidx.annotation.RequiresPermission;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
    private ArrayList<Myitem> items=new ArrayList<>();
    private LayoutInflater inflater;

    public MyAdapter(LayoutInflater inflater, ArrayList<Myitem> myitems, Context context){
        this.inflater=inflater;
        this.items=myitems;
    }
    public MyAdapter(LayoutInflater inflater, Context context){
        this.inflater=inflater;
    }
    public void addItem(Myitem item){
        items.add(item);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
       return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view==null){
            view=inflater.inflate(R.layout.list_item, viewGroup, false);
        }
        MyitemView _view=new MyitemView(view.getContext());
        Myitem item=items.get(i);
        _view.setItem_date(item.getDate());
        _view.setItem_title(item.getTitle());

        LinearLayout linearLayout=(LinearLayout) _view.findViewById(R.id.linear);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //해당 리스트 클릭시
                Intent intent=new Intent(view.getContext(), ReadDiary.class);
                intent.putExtra("date", item.getDate());
                view.getContext().startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        });

        return _view;
    }
}
