package org.example.mydiary;

public class Myitem {
    String date;
    String title;

    public Myitem(String date, String title){
        this.date=date;
        this.title=title;
    }

    public Myitem(){}

    public String getDate(){
        return date;
    }

    public void setDate(String date){
        this.date=date;
    }

    public void setTitle(String title){
        this.title=title;
    }

    public String getTitle() {
        return title;
    }
}
