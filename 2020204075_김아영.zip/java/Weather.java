package org.example.mydiary;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Build;
import android.widget.ProgressBar;

import androidx.annotation.RequiresApi;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Weather extends AsyncTask<String, Void, String> {

    protected void onPreExecute(){
        super.onPreExecute();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected String doInBackground(String... strings) {
        String URL="https://weather.naver.com/";
        String date=strings[0];
        String result=null;
        try {
            //now
            Date now=new Date(System.currentTimeMillis());
            SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
            String d=dateFormat.format(now);
            String[] _now=d.toString().split("-");
            int year, month, day;

            year=Integer.valueOf(_now[0]);
            month=Integer.valueOf(_now[1]);
            day=Integer.valueOf(_now[2]);

            String real_now=Integer.toString(year)+'-'+Integer.toString(month)+'-'+Integer.toString(day);
            Document doc= Jsoup.connect(URL).get();
            //today
            if(date.equals(real_now)){
                Elements sky=doc.select(".current");
                Elements span=doc.select(".weather.before_slash");
                result=sky.text().split(" ")[1].toString()+" "+span.text().toString();
            }
            else{
                //not today
                Elements lo=doc.select("#wrap");
                String location=lo.toString().split(" ")[2].split("=")[1].replace("\"", "");
                Elements find_month=doc.select(".calendar_table");

                String[] _date=date.split("-");
                URL="https://weather.naver.com/today/api/pastWetr?regionCode="+location+"&aplYm="+_date[0]+_date[1];
                doc=Jsoup.connect(URL).ignoreContentType(true).get();

                JSONObject jsonObject=new JSONObject(doc.text());

                JSONArray jsonArray=(JSONArray)jsonObject.get("pastWetrCalendarList");
                String[] data=date.split("-");
                for(int i=0;i<jsonArray.length();i++){

                    JSONObject jsonObject1=jsonArray.getJSONObject(i);
                    String item=jsonObject1.getString("solarDate");
                    //날씨 정렬
                    if(data[1].length()!=2){
                        data[1]="0"+data[1];
                    }

                    if(data[2].length()!=2){
                        data[2]="0"+data[2];
                    }

                    if(item.equals(String.join("", data))){
                        String select_data=jsonObject1.getString("pastWetrData");

                        JSONObject jsonObject2=new JSONObject(select_data);

                        String sky=jsonObject2.getString("wetrTxt");
                        String min=jsonObject2.getString("minTmpr");
                        String max=jsonObject2.getString("maxTmpr");
                        result="최고 온도:"+max+" 최저 온도:"+min+" /"+sky;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    protected void onPostExecute(String result){
        super.onPostExecute(result);
    }

    protected void onCancelled(String result){
        super.onCancelled(result);
    }

}
