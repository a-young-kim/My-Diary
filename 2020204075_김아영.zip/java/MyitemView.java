package org.example.mydiary;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MyitemView extends LinearLayout {
    TextView item_date, item_title;

    public MyitemView(Context context){
        super(context);
        init(context);
    }

    public MyitemView(Context context, AttributeSet attrs){
        super(context, attrs);
        init(context);
    }

    private void init(Context context){
        LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.list_item, this, true);

        item_date=(TextView) findViewById(R.id.item_date);
        item_title=(TextView) findViewById(R.id.item_title);
    }

    public void setItem_date(String date){
        item_date.setText(date);
    }

    public void setItem_title(String title){
        item_title.setText(title);
    }
}
